#include "checker.h"

int main()
{
	Checker c;

	while (true)
		c.check();

	return 0;
}