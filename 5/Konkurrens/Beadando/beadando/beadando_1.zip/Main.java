package beadando;

public class Main {
	public static void main(String[] args) {
		try {
			Farm f = new Farm(8, 3, 1);

			f.Run();

			// Thread.sleep(5000);

			// f.Stop();
		} catch (Exception e) {
			System.out.println("Baj van valamivel");
		}
	}
}