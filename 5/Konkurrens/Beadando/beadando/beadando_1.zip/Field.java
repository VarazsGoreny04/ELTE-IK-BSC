package beadando;

public final class Field extends Area {
	@Override
	public String toString() {
		return " ";
	}
}