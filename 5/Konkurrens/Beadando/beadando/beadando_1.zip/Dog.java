package beadando;

import java.util.ArrayList;
import java.util.List;

public class Dog extends Animal {

	public Dog(Tile[][] farm, Point location, int number) throws Exception {
		super(farm, location);

		if (number < 0 || number > 9 || InnerCircle(location))
			throw new Exception();

		name = number;
	}

	public void Move() {
		Point[] ps = new Point[4];

		ps[0] = Point.Add(location, new Point(-1, 0));
		ps[1] = Point.Add(location, new Point(1, 0));
		ps[2] = Point.Add(location, new Point(0, -1));
		ps[3] = Point.Add(location, new Point(0, 1));

		synchronized (GetTileAt(location)) {
		synchronized (GetTileAt(ps[0])) {
		synchronized (GetTileAt(ps[1])) {
		synchronized (GetTileAt(ps[2])) {
		synchronized (GetTileAt(ps[3])) {
			List<Integer> haventChecked = new ArrayList<Integer>(4);

			for (int i = 0; i < Dir.array.length; ++i)
				haventChecked.add(i);

			C frontCheck = FrontCheck();

			while (true) {
				if (haventChecked.size() < 1)
					return;
				else if (frontCheck == C.anT)
					direction = haventChecked.get(rnd.nextInt(haventChecked.size()));
				else if (frontCheck == C.an) {
					Step(direction);

					return;
				} else
					System.out.println("Kapitulált a kutya!");

				haventChecked.remove(haventChecked.indexOf(direction));
			}
		}}}}}
	}

	protected C FrontCheck() {
		Point front = (Point.Add(location, Dir.array[direction]));

		Area temp = farm[front.x][front.y].GetArea();

		if (temp instanceof Field)
			return C.an;
		else
			return C.anT;
	}

	protected void Step(int directionNum) {
		Point destination = Point.Add(location, Dir.array[directionNum]);
		Area temp = GetTileAt(destination).GetArea();

		if (!(temp instanceof Field)) {
			for (int i = 0; i < 5; ++i)
				System.out.println("Nem mezo b");
		} else {
			GetTileAt(destination).SetArea(this);
			GetTileAt(location).SetArea(temp);
			this.location = destination;
		}
	}

	@Override
	public String toString() {
		return Integer.toString(name);
	}
}