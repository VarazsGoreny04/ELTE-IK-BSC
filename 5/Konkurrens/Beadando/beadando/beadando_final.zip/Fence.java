package beadando;

public final class Fence extends Area {
	@Override
	public String toString() {
		return "#";
	}
}