package beadando;

public class Main {
	public static void main(String[] args) {
		try {
			Farm f = new Farm();

			f.Run();
		} catch (Exception e) {
			System.out.println(e);
			System.out.println("Something went wrong!");
		}
	}
}