package beadando;

public final class Gate extends Area {
	@Override
	public String toString() {
		return " ";
	}
}