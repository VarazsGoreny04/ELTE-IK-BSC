package beadando;

public abstract class Area {

	public void Run() {
	}

	public void Stop() {
	}

	@Override
	public abstract String toString();
}