package beadando;

import java.util.Random;
import java.util.List;
import java.util.ArrayList;

public class Farm {
	public final int length;
	private Tile[][] farm;
	private boolean active;

	public Farm(int length, int sheepNumber, int dogNumber) throws Exception {
		// Parameter checking
		if (/* length < 14 || */ length % 3 != 2 || sheepNumber < 1 || dogNumber < 1) {
			System.out.println("Baj van a parameterekkel!");
			throw new Exception();
		}

		// Generating base farm (fence and fields)
		this.length = length;
		farm = new Tile[this.length][this.length];

		int lenInd = (this.length - 1);
		for (int x = 0; x < farm.length; ++x) {
			for (int y = 0; y < farm.length; ++y) {
				if (x == 0 || y == 0 || x == lenInd || y == lenInd)
					farm[x][y] = new Tile(new Fence());
				else
					farm[x][y] = new Tile(new Field());
			}
		}

		// Generating gates
		Random rnd = new Random();

		farm[0][rnd.nextInt(lenInd - 1) + 1] = new Tile(new Gate());
		farm[lenInd][rnd.nextInt(lenInd - 1) + 1] = new Tile(new Gate());
		farm[rnd.nextInt(lenInd - 1) + 1][0] = new Tile(new Gate());
		farm[rnd.nextInt(lenInd - 1) + 1][lenInd] = new Tile(new Gate());

		// Generating sheeps and dogs
		List<Point> sheepCoords = new ArrayList<Point>();
		List<Point> dogCoords = new ArrayList<Point>();

		{
			Animal helperDog = new Dog(farm, new Point(1, 1), 9);

			for (int x = 1; x < farm.length - 1; ++x) {
				for (int y = 1; y < farm.length - 1; ++y) {
					if (!(farm[x][y].GetArea() instanceof Fence)) {
						Point current = new Point(x, y);

						if (helperDog.InnerCircle(current))
							sheepCoords.add(current);
						else
							dogCoords.add(current);
					}
				}
			}
		}

		Point point;

		for (int i = 0; i < sheepNumber; ++i) {
			point = sheepCoords.remove(rnd.nextInt(sheepCoords.size()));
			farm[point.x][point.y].SetArea(new Sheep(farm, point, i));
		}

		for (int i = 0; i < dogNumber; ++i) {
			point = dogCoords.remove(rnd.nextInt(dogCoords.size()));
			farm[point.x][point.y].SetArea(new Dog(farm, point, i));
		}
	}

	public void Run() {
		active = true;
		System.out.println("\033[H\033[2J");
		ShowFarm();

		try {
			Thread.sleep(100);
		} catch (Exception e) {
			System.out.println("Már ez sem működik... xd");
		}

		for (int x = 0; x < farm.length; ++x) {
			for (int y = 0; y < farm.length; ++y)
				farm[x][y].Run();
		}

		try {
			Thread.sleep(100);

			while (active) {
				ShowFarm();
				Thread.sleep(200);
			}
		} catch (Exception e) {
			System.out.println("Baj van a futtatassal!");
			Stop();
		}
	}

	public void Stop() {
		for (int x = 0; x < farm.length; ++x) {
			for (int y = 0; y < farm.length; ++y)
				farm[x][y].Stop();
		}

		active = false;
	}

	public void ShowFarm() {
		StringBuilder sb = new StringBuilder();

		for (int x = 0; x < farm.length; ++x) {
			for (int y = 0; y < farm.length; ++y) {
				sb.append(farm[x][y].toString());
				sb.append(" ");
			}

			sb.append('\n');
		}

		// System.out.println("\u001B[0;0H");
		System.out.println(sb.toString());
	}
}