﻿namespace Complex_menu
{
	class Program
	{
		public static void Main()
		{
			Menu m = new();
			m.Run();
		}
	}
}