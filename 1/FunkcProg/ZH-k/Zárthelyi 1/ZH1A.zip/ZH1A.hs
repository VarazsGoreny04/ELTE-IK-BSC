module ZH1A where

    --Kérdés: Mert nincs meghatározva az a típusa

    scalar :: (Int, Int, Int) -> (Int, Int, Int) -> Int
    scalar (a, b, c) (d, e, f) = (a * d) + (b * e) + (c * f)

    numbers :: [Int]
    numbers = [x | x <- [1000,999..1], x `mod` 5 == 3, (3 * x) `mod` 7 == 2]

    logicalFunctionA :: Bool -> Bool -> Bool -> Bool
    logicalFunctionA True True True = True
    logicalFunctionA True True False = False
    logicalFunctionA True False True = True
    logicalFunctionA True False False = True
    logicalFunctionA False True True = False
    logicalFunctionA False True False = True
    logicalFunctionA False False True = True
    logicalFunctionA False False False = False

