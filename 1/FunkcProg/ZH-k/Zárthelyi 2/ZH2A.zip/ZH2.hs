module Zárthelyi_2_A where

--1. elméleti kérdés: Nincs definiálva az üreslistára visszatérési érték mintaillesztéssel.
--2. elméleti kérdés: [(a,[b]),c]

duplicateEverySecond :: [a] -> [a]
duplicateEverySecond [] = []
duplicateEverySecond (x:[]) = [x]
duplicateEverySecond (x:y:xs) = x : y : y : duplicateEverySecond xs

sortTuples :: Ord a => [(a,a)] -> [(a,a)]
sortTuples [] = []
sortTuples ((x,y):xs)
    | x < y = (x,y) : sortTuples xs
    | y < x = (y,x) : sortTuples xs

interleave :: [a] -> [a] -> [a]
interleave [] ys = ys
interleave xs [] = xs
interleave (x:xs) (y:ys) = x : y : interleave xs ys 