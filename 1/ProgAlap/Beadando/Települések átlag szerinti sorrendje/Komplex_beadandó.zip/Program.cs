﻿using System;
using System.Collections.Generic;
namespace Települések_átlag_szerinti_sorrendje
{
	internal class Program
	{
		static void Main()
		{
			int n = 0, m = 0;
			Data(ref n, ref m);
			int[,] villages = new int[n ,m];
			Input(villages, n, m);
			(int, int)[] avgs = new (int, int)[n]; 
			Calculate(villages, n, m, avgs);
			Output(avgs, n);
		}
		static void Data(ref int n, ref int m)
		{
			Console.Error.WriteLine("Adja meg a települések és a hozzájuk tartozó adatok számát:");
			bool error = false;
			do
			{
				if (error)
					Console.Error.WriteLine("Hibás értéket adott meg!");
				string[] part = Console.ReadLine().Split();
				error = part.Length != 2 || !int.TryParse(part[0], out n) || !int.TryParse(part[1], out m) || n < 1 || n > 1000 || m < 1 || m > 1000;
			} while (error);
		}
		static void Input(int[,] villages, int n, int m)
		{
			Console.Error.WriteLine("Adja meg az adatokat:");
			for (int i = 0; i < n; ++i)
			{
				bool error;
				do
				{
					bool pError = false, lError;
					string[] peaces = Console.ReadLine().Split();
					if (lError = peaces.Length == m)
					{
						for (int j = 0; j < m; ++j)
						{
							if (!int.TryParse(peaces[j], out villages[i, j]) || villages[i, j] < -50 || villages[i, j] > 50)
								pError = true;
						}
					}
					error = pError || !lError;
					if (error)
						Console.Error.WriteLine("Hibás értéket adott meg!");
				} while (error);
			}
		}
		static void Calculate(int[,] villages, int n, int m, (int, int)[] avgs)
		{
			for (int i = 0; i < n; ++i)
			{
				int sum = 0;
				for (int j = 0; j < m; ++j)
					sum += villages[i, j];
				avgs[i] = (i + 1, sum);
			}
			(int, int) temp;
			int k = n - 1, cut, t;
			while (k > 1)
			{
				cut = 0;
				for (int l = 0; l < k; ++l)
				{
					t = l + 1;
					if (avgs[l].Item2 < avgs[t].Item2)
					{
						temp = avgs[l];
						avgs[l] = avgs[t];
						avgs[t] = temp;
						cut = l;
					}
				}
				k = cut;
			}
		}
		static void Output((int, int)[] avgs, int n)
		{
			for (int i = 0; i < n; ++i)
				Console.Write($"{avgs[i].Item1} ");
		}
	}
}