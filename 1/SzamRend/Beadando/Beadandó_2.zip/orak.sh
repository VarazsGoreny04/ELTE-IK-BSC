#!/bin/sh

IFS=',$'
text=`cat -E $1`
szTeacher=""
teacher=""
szNull=0
counter=0
numOfClasses=0
activationKey=0

echo
echo "a feladat:"
for i in $text
do
if [ `expr $counter % 6` -eq 0 ]; then
teacher=$i
elif [ "$i" = " Sz" ]; then
szTeacher="$szTeacher$teacher"
szNull=`expr $szNull + 1`
fi
counter=`expr $counter + 1`
done
if [ $szNull -gt 0 ]; then
echo $szTeacher
else
echo "NINCS"
fi

echo
echo "b feladat:"
counter=0
for i in $text
do
if [ `expr $counter % 6` -eq 0 ]; then
teacher=$i
else
IFS=' '
for j in $i
do
if [ "$j" != "H" -a "$j" != "K" -a "$j" != "Sz" -a "$j" != "Cs" -a "$j" != "P" ]; then
numOfClasses=`expr $numOfClasses + 1`
fi
done
IFS=',$'
fi
counter=`expr $counter + 1`
if [ `expr $counter % 6` -eq 0 ]; then
echo -n $teacher: $numOfClasses
numOfClasses=0
fi
done
echo

echo
echo "c feladat:"
read day
counter=0
first=""
for i in $text
do
if [ `expr $counter % 6` -eq 0 ]; then
teacher=$i
else
IFS=' '
for j in $i
do
if [ $j = $day ]; then
activationKey=1
elif [ $activationKey -eq 1 -a $j = "1" ]; then
first="$first$teacher"
else
activationKey=0
fi
done
IFS=',$'
fi
counter=`expr $counter + 1`
done
if [ -z "$first" ]; then
echo "NINCS"
else
echo $first
fi
echo