#include <string>
#include "MyApp.h"
#include "ObjParser.h"
#include "SDL_GLDebugMessageCallback.h"

#include <imgui.h>

CMyApp::CMyApp()
{
}

CMyApp::~CMyApp()
{
}

void CMyApp::SetupDebugCallback()
{
	// engedélyezzük és állítsuk be a debug callback függvényt ha debug context-ben vagyunk
	GLint context_flags;
	glGetIntegerv(GL_CONTEXT_FLAGS, &context_flags);
	if (context_flags & GL_CONTEXT_FLAG_DEBUG_BIT) {
		glEnable(GL_DEBUG_OUTPUT);
		glEnable(GL_DEBUG_OUTPUT_SYNCHRONOUS);
		glDebugMessageControl(GL_DONT_CARE, GL_DONT_CARE, GL_DEBUG_SEVERITY_NOTIFICATION, 0, nullptr, GL_FALSE);
		glDebugMessageControl(GL_DONT_CARE, GL_DEBUG_TYPE_DEPRECATED_BEHAVIOR, GL_DONT_CARE, 0, nullptr, GL_FALSE);
		glDebugMessageCallback(SDL_GLDebugMessageCallback, nullptr);
	}
}

void CMyApp::InitShaders()
{
	m_programID = glCreateProgram();
	AttachShader(m_programID, GL_VERTEX_SHADER, "Shaders/Vert_PosNormTex.vert");
	AttachShader(m_programID, GL_FRAGMENT_SHADER, "Shaders/Frag_ZH.frag");
	LinkProgram(m_programID);
}

void CMyApp::CleanShaders()
{
	glDeleteProgram(m_programID);
}

MeshObject<Vertex> createCube()
{
	MeshObject<Vertex> mesh;

	mesh.vertexArray = {
		// Elülső oldala 
		{{-0.5f, -0.5f, 0.5f}, {0.0f, 0.0f, 1.0f}, {0.0f, 0.0f}}, // Bal lent 
		{{0.5f, -0.5f, 0.5f}, {0.0f, 0.0f, 1.0f}, {1.0f, 0.0f}},  // Jobb lent 
		{{0.5f, 0.5f, 0.5f}, {0.0f, 0.0f, 1.0f}, {1.0f, 1.0f}},   // Jobb fent 
		{{-0.5f, 0.5f, 0.5f}, {0.0f, 0.0f, 1.0f}, {0.0f, 1.0f}},  // Bal fent 

		// Hátulsó oldala 
		{{0.5f, -0.5f, -0.5f}, {0.0f, 0.0f, -1.0f}, {0.0f, 0.0f}}, // Bal lent 
		{{-0.5f, -0.5f, -0.5f}, {0.0f, 0.0f, -1.0f}, {1.0f, 0.0f}},// Jobb lent 
		{{-0.5f, 0.5f, -0.5f}, {0.0f, 0.0f, -1.0f}, {1.0f, 1.0f}}, // Jobb fent 
		{{0.5f, 0.5f, -0.5f}, {0.0f, 0.0f, -1.0f}, {0.0f, 1.0f}},  // Bal fent 

		// Bal oldala 
		{{-0.5f, -0.5f, -0.5f}, {-1.0f, 0.0f, 0.0f}, {0.0f, 0.0f}},// Bal lent 
		{{-0.5f, -0.5f, 0.5f}, {-1.0f, 0.0f, 0.0f}, {1.0f, 0.0f}}, // Jobb lent 
		{{-0.5f, 0.5f, 0.5f}, {-1.0f, 0.0f, 0.0f}, {1.0f, 1.0f}},  // Jobb fent 
		{{-0.5f, 0.5f, -0.5f}, {-1.0f, 0.0f, 0.0f}, {0.0f, 1.0f}}, // Bal fent 

		// Jobb oldala 
		{{0.5f, -0.5f, 0.5f}, {1.0f, 0.0f, 0.0f}, {0.0f, 0.0f}},  // Bal lent 
		{{0.5f, -0.5f, -0.5f}, {1.0f, 0.0f, 0.0f}, {1.0f, 0.0f}}, // Jobb lent 
		{{0.5f, 0.5f, -0.5f}, {1.0f, 0.0f, 0.0f}, {1.0f, 1.0f}},  // Jobb fent 
		{{0.5f, 0.5f, 0.5f}, {1.0f, 0.0f, 0.0f}, {0.0f, 1.0f}},   // Bal fent 

		// Felső oldala 
		{{-0.5f, 0.5f, 0.5f}, {0.0f, 1.0f, 0.0f}, {0.0f, 0.0f}},  // Bal lent 
		{{0.5f, 0.5f, 0.5f}, {0.0f, 1.0f, 0.0f}, {1.0f, 0.0f}},   // Jobb lent 
		{{0.5f, 0.5f, -0.5f}, {0.0f, 1.0f, 0.0f}, {1.0f, 1.0f}},  // Jobb fent 
		{{-0.5f, 0.5f, -0.5f}, {0.0f, 1.0f, 0.0f}, {0.0f, 1.0f}}, // Bal fent 

		// Alsó oldala 
		{{-0.5f, -0.5f, -0.5f}, {0.0f, -1.0f, 0.0f}, {0.0f, 0.0f}},// Bal lent 
		{{0.5f, -0.5f, -0.5f}, {0.0f, -1.0f, 0.0f}, {1.0f, 0.0f}}, // Jobb lent 
		{{0.5f, -0.5f, 0.5f}, {0.0f, -1.0f, 0.0f}, {1.0f, 1.0f}},  // Jobb fent 
		{{-0.5f, -0.5f, 0.5f}, {0.0f, -1.0f, 0.0f}, {0.0f, 1.0f}}, // Bal fent 
	};

	mesh.indexArray = {// Elülső oldala 
						 0, 1, 2, 2, 3, 0,
						 // Hátulsó oldala 
						 4, 5, 6, 6, 7, 4,
						 // Bal oldala 
						 8, 9, 10, 10, 11, 8,
						 // Jobb oldala 
						 12, 13, 14, 14, 15, 12,
						 // Felső oldala 
						 16, 17, 18, 18, 19, 16,
						 // Alsó oldala 
						 20, 21, 22, 22, 23, 20 };

	return mesh;
}

// Quad 
MeshObject<Vertex> createQuad()
{
	MeshObject<Vertex> quadMeshCPU;

	quadMeshCPU.vertexArray =
	{
		{ glm::vec3(-0.5, 0 ,  0.5),glm::vec3(0.0, 1.0, 0.0), glm::vec2(0.0, 0.0) },
		{ glm::vec3(0.5, 0 ,  0.5),glm::vec3(0.0, 1.0, 0.0), glm::vec2(1.0, 0.0) },
		{ glm::vec3(-0.5, 0 , -0.5),glm::vec3(0.0, 1.0, 0.0), glm::vec2(0.0, 1.0) },
		{ glm::vec3(0.5, 0 , -0.5),glm::vec3(0.0, 1.0, 0.0), glm::vec2(1.0, 1.0) }
	};

	quadMeshCPU.indexArray =
	{
		0, 1, 2,
		1, 3, 2
	};

	return quadMeshCPU;
}

void CMyApp::InitGeometry()
{
	const std::initializer_list<VertexAttributeDescriptor> vertexAttribList =
	{
		{0, offsetof(Vertex, position), 3, GL_FLOAT},
		{1, offsetof(Vertex, normal), 3, GL_FLOAT},
		{2, offsetof(Vertex, texcoord), 2, GL_FLOAT},
	};

	m_rectangleGPU = CreateGLObjectFromMesh(createQuad(), vertexAttribList);

	MeshObject<Vertex> mesh;

	mesh = ObjParser::parse("Assets/f16_full_body.obj");
	m_planeFullBodyGPU = CreateGLObjectFromMesh(mesh, vertexAttribList);
	mesh = ObjParser::parse("Assets/f16_right_wing_flaps.obj");
	m_planeRWingFlapGPU = CreateGLObjectFromMesh(mesh, vertexAttribList);
	mesh = ObjParser::parse("Assets/f16_left_wing_flaps.obj");
	m_planeLWingFlapGPU = CreateGLObjectFromMesh(mesh, vertexAttribList);
	mesh = ObjParser::parse("Assets/f16_right_tail_flap.obj");
	m_planeRTailFlapGPU = CreateGLObjectFromMesh(mesh, vertexAttribList);
	mesh = ObjParser::parse("Assets/f16_left_tail_flap.obj");
	m_planeLTailFlapGPU = CreateGLObjectFromMesh(mesh, vertexAttribList);
}

void CMyApp::CleanGeometry()
{
	CleanOGLObject(m_rectangleGPU);
	CleanOGLObject(m_planeFullBodyGPU);
	CleanOGLObject(m_planeRWingFlapGPU);
	CleanOGLObject(m_planeLWingFlapGPU);
	CleanOGLObject(m_planeRTailFlapGPU);
	CleanOGLObject(m_planeLTailFlapGPU);
}

void CMyApp::InitTextures()
{
	glCreateSamplers(1, &m_SamplerID);
	glSamplerParameteri(m_SamplerID, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glSamplerParameteri(m_SamplerID, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glSamplerParameteri(m_SamplerID, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glSamplerParameteri(m_SamplerID, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glCreateSamplers(1, &m_RepeatSamplerID);
	glSamplerParameteri(m_RepeatSamplerID, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glSamplerParameteri(m_RepeatSamplerID, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glSamplerParameteri(m_RepeatSamplerID, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glSamplerParameteri(m_RepeatSamplerID, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	ImageRGBA image = ImageFromFile("Assets/Color_checkerboard.png");

	glCreateTextures(GL_TEXTURE_2D, 1, &m_cubeTextureID);
	glTextureStorage2D(m_cubeTextureID, NumberOfMIPLevels(image), GL_RGBA8, image.width, image.height);
	glTextureSubImage2D(m_cubeTextureID, 0, 0, 0, image.width, image.height, GL_RGBA, GL_UNSIGNED_BYTE, image.data());

	glGenerateTextureMipmap(m_cubeTextureID);

	image = ImageFromFile("Assets/f16_texture.jpg");

	glCreateTextures(GL_TEXTURE_2D, 1, &m_planeTextureID);
	glTextureStorage2D(m_planeTextureID, NumberOfMIPLevels(image), GL_RGBA8, image.width, image.height);
	glTextureSubImage2D(m_planeTextureID, 0, 0, 0, image.width, image.height, GL_RGBA, GL_UNSIGNED_BYTE, image.data());

	glGenerateTextureMipmap(m_planeTextureID);

	image = ImageFromFile("Assets/sky_base.jpg");

	glCreateTextures(GL_TEXTURE_2D, 1, &m_skyTextureID);
	glTextureStorage2D(m_skyTextureID, NumberOfMIPLevels(image), GL_RGBA8, image.width, image.height);
	glTextureSubImage2D(m_skyTextureID, 0, 0, 0, image.width, image.height, GL_RGBA, GL_UNSIGNED_BYTE, image.data());

	glGenerateTextureMipmap(m_skyTextureID);

	image = ImageFromFile("Assets/ground_base.jpg");

	glCreateTextures(GL_TEXTURE_2D, 1, &m_groundTextureID);
	glTextureStorage2D(m_groundTextureID, NumberOfMIPLevels(image), GL_RGBA8, image.width, image.height);
	glTextureSubImage2D(m_groundTextureID, 0, 0, 0, image.width, image.height, GL_RGBA, GL_UNSIGNED_BYTE, image.data());

	glGenerateTextureMipmap(m_groundTextureID);

	image = ImageFromFile("Assets/sky_map.jpg");

	glCreateTextures(GL_TEXTURE_2D, 1, &m_skyMapTextureID);
	glTextureStorage2D(m_skyMapTextureID, NumberOfMIPLevels(image), GL_RGBA8, image.width, image.height);
	glTextureSubImage2D(m_skyMapTextureID, 0, 0, 0, image.width, image.height, GL_RGBA, GL_UNSIGNED_BYTE, image.data());

	glGenerateTextureMipmap(m_skyMapTextureID);
}

void CMyApp::CleanTextures()
{
	glDeleteTextures(1, &m_cubeTextureID);
	glDeleteTextures(1, &m_planeTextureID);
	glDeleteTextures(1, &m_skyTextureID);
	glDeleteTextures(1, &m_groundTextureID);
	glDeleteTextures(1, &m_skyMapTextureID);

	glDeleteSamplers(1, &m_SamplerID);
	glDeleteSamplers(1, &m_RepeatSamplerID);
}

bool CMyApp::Init()
{
	SetupDebugCallback();

	// törlési szín legyen kékes
	glClearColor(0.85f, 0.85f, 0.95f, 1.0f);

	InitShaders();
	InitGeometry();
	InitTextures();

	// egyéb inicializálás

	glEnable(GL_CULL_FACE); // kapcsoljuk be a hátrafelé néző lapok eldobását 
	glCullFace(GL_BACK);    // GL_BACK: a kamerától "elfelé" néző lapok, GL_FRONT: a kamera felé néző lapok 

	glEnable(GL_DEPTH_TEST); // mélységi teszt bekapcsolása (takarás) 

	// kamera 
	m_camera.SetView(
		glm::vec3(-20.0, 20.0, 20.0),  // honnan nézzük a színteret - eye
		glm::vec3(0.0, 0.0, 0.0),  // a színtér melyik pontját nézzük - at
		glm::vec3(0.0, 1.0, 0.0)); // felfelé mutató irány a világban - up

	m_cameraManipulator.SetCamera(&m_camera);

	barrelRoll.duration = 2;
	barrelRoll.rotation = glm::vec3(0, 0, 1);
	barrelRoll.rFlap = -35;
	barrelRoll.lFlap = 35;
	barrelRoll.rTail = -15;
	barrelRoll.lTail = 15;

	return true;
}

void CMyApp::Clean()
{
	CleanShaders();
	CleanGeometry();
	CleanTextures();
}

static bool HitPlane(const Ray& ray, const glm::vec3& planeQ, const glm::vec3& planeI, const glm::vec3& planeJ, Intersection& result)
{
	// sík parametrikus egyenlete: planeQ + u * planeI + v * planeJ
	glm::mat3 A(-ray.direction, planeI, planeJ);
	glm::vec3 B = ray.origin - planeQ;

	if (fabsf(glm::determinant(A)) < 1e-6) return false;
	glm::vec3 X = glm::inverse(A) * B;

	if (X.x < 0.0) {
		return false;
	}
	result.t = X.x;
	result.uv.x = X.y;
	result.uv.y = X.z;

	return true;
}


static bool HitSphere(const glm::vec3& rayOrigin, const glm::vec3& rayDir, const glm::vec3& sphereCenter, float sphereRadius, float& t)
{
	glm::vec3 p_m_c = rayOrigin - sphereCenter;
	float a = glm::dot(rayDir, rayDir);
	float b = 2.0f * glm::dot(rayDir, p_m_c);
	float c = glm::dot(p_m_c, p_m_c) - sphereRadius * sphereRadius;

	float discriminant = b * b - 4.0f * a * c;

	if (discriminant < 0.0f)
	{
		return false;
	}

	float sqrtDiscriminant = sqrtf(discriminant);

	// Mivel 2*a és sqrt(D) mindig pozitívak, ezért tudjuk, hogy t0 < t1
	float t0 = (-b - sqrtDiscriminant) / (2.0f * a);
	float t1 = (-b + sqrtDiscriminant) / (2.0f * a);

	if (t1 < 0.0f) // mivel t0 < t1, ha t1 negatív, akkor t0 is az 
	{
		return false;
	}

	if (t0 < 0.0f)
	{
		t = t1;
	}
	else
	{
		t = t0;
	}

	return true;
}

Ray CMyApp::CalculatePixelRay(glm::vec2 pixel) const
{
	// NDC koordináták kiszámítása 
	glm::vec3 pickedNDC = glm::vec3(
		2.0f * (pixel.x + 0.5f) / m_windowSize.x - 1.0f,
		1.0f - 2.0f * (pixel.y + 0.5f) / m_windowSize.y, 0.0f);

	// A világ koordináták kiszámítása az inverz ViewProj mátrix segítségével
	glm::vec4 pickedWorld = glm::inverse(m_camera.GetViewProj()) * glm::vec4(pickedNDC, 1.0f);
	pickedWorld /= pickedWorld.w; // homogén osztás 
	Ray ray;

	// Raycasting kezdőpontja a kamera pozíciója 
	ray.origin = m_camera.GetEye();
	// Iránya a kamera pozíciójából a kattintott pont világ koordinátái felé 
	// FIGYELEM: NEM egység hosszúságú vektor! 
	ray.direction = glm::vec3(pickedWorld) - ray.origin;
	return ray;
}

void CMyApp::Update(const SUpdateInfo& updateInfo)
{
	m_LastElapsedTimeInSec = m_ElapsedTimeInSec;
	m_ElapsedTimeInSec = updateInfo.ElapsedTimeInSec;

	m_GameElapsedTimeInSec += (m_ElapsedTimeInSec - m_LastElapsedTimeInSec) * time;

	if (m_IsPicking) {
		// a felhasználó Ctrl + kattintott, itt kezeljük le
		// sugár indítása a kattintott pixelen át
		Ray ray = CalculatePixelRay(glm::vec2(m_PickedPixel.x, m_PickedPixel.y));
		Intersection intersect;
		HitPlane(ray, glm::vec3(0.0, 0.0, 0.0), glm::vec3(500.0, 0.0, 0.0), glm::vec3(0.0, 0.0, 500.0), intersect);

		formations[3].push_back(glm::vec3(intersect.uv.x * 500.0, 0.0, intersect.uv.y * 500.0));

		m_IsPicking = false;
	}

	m_cameraManipulator.Update(updateInfo.DeltaTimeInSec);

	m_objectWorldTransform = glm::translate(OBJECT_POS);
}

void CMyApp::SetCommonUniforms()
{
	// - Uniform paraméterek 
	glUniform1f( ul("ElapsedTimeInSec"), m_GameElapsedTimeInSec);

	// - view és projekciós mátrix 
	glUniformMatrix4fv(ul("viewProj"), 1, GL_FALSE, glm::value_ptr(m_camera.GetViewProj()));

	// - Fényforrások beállítása 
	glUniform3fv( ul("cameraPosition"), 1, glm::value_ptr(m_camera.GetEye()));
	//glUniform4fv( ul("lightPosition"), 1, glm::value_ptr(m_lightPosition));
	//glUniform3fv( ul("La"), 1, glm::value_ptr(m_La));
	//glUniform3fv( ul("Ld"), 1, glm::value_ptr(m_Ld));
	//glUniform3fv( ul("Ls"), 1, glm::value_ptr(m_Ls));
	//glUniform1f( ul("lightConstantAttenuation"), m_lightConstantAttenuation);
	//glUniform1f( ul("lightLinearAttenuation"), m_lightLinearAttenuation);
	//glUniform1f( ul("lightQuadraticAttenuation"), m_lightQuadraticAttenuation);
}

void CMyApp::DrawObject(OGLObject& obj, const glm::mat4& world) {
	glUniformMatrix4fv(ul("world"), 1, GL_FALSE, glm::value_ptr(world));
	glUniformMatrix4fv(ul("worldInvTransp"), 1, GL_FALSE, glm::value_ptr(glm::transpose(glm::inverse(world))));
	glBindVertexArray(obj.vaoID);
	glDrawElements(GL_TRIANGLES, obj.count, GL_UNSIGNED_INT, nullptr);
}

void CMyApp::RenderEarth()
{
	glBindTextureUnit(1, m_skyMapTextureID);
	glBindSampler(1, m_SamplerID);
	glUniform1i(ul("textureSky"), 1);      

	glUniform1i(ul("state"), 2);

	glBindSampler(0, m_RepeatSamplerID);
	glBindTextureUnit(0, m_skyTextureID);

	DrawObject(m_rectangleGPU, glm::translate(glm::vec3(0.0, 50.0, 0.0)) * glm::scale(glm::vec3(500.f, 0.f, 500.f)) * glm::rotate(glm::pi<float>(), glm::vec3(0, 0, 1)));

	glBindTextureUnit(0, m_groundTextureID);

	DrawObject(m_rectangleGPU, glm::translate(glm::vec3(0.0, -50.0, 0.0)) * glm::scale(glm::vec3(500.f, 0.f, 500.f)));

	glBindSampler(0, m_SamplerID);

	glUniform1i(ul("state"), 0);
}

void CMyApp::RenderPlane()
{
	glBindTextureUnit(1, m_skyMapTextureID);
	glBindSampler(1, m_SamplerID);
	glUniform1i(ul("textureSky"), 1);

	glUniform1i(ul("state"), 1);

	glBindTextureUnit(0, m_planeTextureID);

	for (int i = 0; i < formations[formationSelected].size(); ++i)
	{
		glm::mat4 planeBody = glm::translate(formations[formationSelected][i]);

		glUniform3fv(ul("planePosition"), 1, &formations[formationSelected][i].x);

		DrawObject(m_planeFullBodyGPU, planeBody);
		DrawObject(m_planeRWingFlapGPU, planeBody * glm::translate(glm::vec3(-1.715, 0.007, -0.249)) * glm::rotate(-9.f * glm::pi<float>() / 180.f, glm::vec3(0, 1, 0)) * glm::rotate(rFlap, glm::vec3(1, 0, 0)));
		DrawObject(m_planeLWingFlapGPU, planeBody * glm::translate(glm::vec3(1.715, 0.007, -0.249)) * glm::rotate(9.f * glm::pi<float>() / 180.f, glm::vec3(0, 1, 0)) * glm::rotate(lFlap, glm::vec3(1, 0, 0)));
		DrawObject(m_planeRTailFlapGPU, planeBody * glm::translate(glm::vec3(-0.664, 0.023, -1.997)) * glm::rotate(rTail, glm::vec3(1, 0, 0)));
		DrawObject(m_planeLTailFlapGPU, planeBody * glm::translate(glm::vec3(0.664, 0.023, -1.997)) * glm::rotate(lTail, glm::vec3(1, 0, 0)));
	}

	glUniform1i(ul("state"), 0);
}


void CMyApp::Render()
{
	// töröljük a framepuffert (GL_COLOR_BUFFER_BIT)...
	// ... és a mélységi Z puffert (GL_DEPTH_BUFFER_BIT)
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glUseProgram(m_programID);
	glBindSampler(0, m_SamplerID);
	glUniform1i(ul("state"), 0);

	SetCommonUniforms();

	RenderEarth();
	RenderPlane();

	glBindVertexArray(0);
	// shader kikapcsolása 
	glUseProgram(0);
}

void CMyApp::RenderGUI()
{
	if (ImGui::Begin("Window"))
	{
		ImGui::SliderFloat("Time", &time, 0.5, 2.0);

		if (ImGui::Button("Manouver"))
			doAFlip = true;

		if (ImGui::Button("Default formation"))
			formationSelected = 0;
		if (ImGui::Button("Square formation"))
			formationSelected = 1;
		if (ImGui::Button("Triangle formation"))
			formationSelected = 2;
		if (ImGui::Button("Custom formation"))
			formationSelected = 3;
		if (formationSelected == 3)
		{
			if (ImGui::Button("Delete custom formation"))
				formations[3].clear();

			ImGui::BeginListBox("listbox");
			for (int i = 0; i < formations[3].size(); ++i)
			{
				ImGui::InputFloat3("" + i, &formations[3][i].x);
			}
			ImGui::EndListBox();
		}

		ImGui::SliderAngle("Right flap", &rFlap, -30, 30);
		ImGui::SliderAngle("Left flap", &lFlap, -30, 30);
		ImGui::SliderAngle("Right tail", &rTail, -30, 30);
		ImGui::SliderAngle("Left tail", &lTail, -30, 30);
	}
	ImGui::End();
}

// https://wiki.libsdl.org/SDL2/SDL_KeyboardEvent
// https://wiki.libsdl.org/SDL2/SDL_Keysym
// https://wiki.libsdl.org/SDL2/SDL_Keycode
// https://wiki.libsdl.org/SDL2/SDL_Keymod

void CMyApp::KeyboardDown(const SDL_KeyboardEvent& key)
{
	if (key.repeat == 0) // Először lett megnyomva 
	{
		if (key.keysym.sym == SDLK_F5 && key.keysym.mod & KMOD_CTRL)
		{
			CleanShaders();
			InitShaders();
		}
		if (key.keysym.sym == SDLK_F1)
		{
			GLint polygonModeFrontAndBack[2] = {};
			// https://registry.khronos.org/OpenGL-Refpages/gl4/html/glGet.xhtml
			glGetIntegerv(GL_POLYGON_MODE, polygonModeFrontAndBack); // Kérdezzük le a jelenlegi polygon módot! Külön adja a front és back módokat. 
			GLenum polygonMode = (polygonModeFrontAndBack[0] != GL_FILL ? GL_FILL : GL_LINE); // Váltogassuk FILL és LINE között! 
			// https://registry.khronos.org/OpenGL-Refpages/gl4/html/glPolygonMode.xhtml
			glPolygonMode(GL_FRONT_AND_BACK, polygonMode); // Állítsuk be az újat! 
		}

		if (key.keysym.sym == SDLK_LCTRL || key.keysym.sym == SDLK_RCTRL)
		{
			m_IsCtrlDown = true;
		}
	}
	m_cameraManipulator.KeyboardDown(key);
}

void CMyApp::KeyboardUp(const SDL_KeyboardEvent& key)
{
	m_cameraManipulator.KeyboardUp(key);
	if (key.keysym.sym == SDLK_LCTRL || key.keysym.sym == SDLK_RCTRL)
	{
		m_IsCtrlDown = false;
	}
}

// https://wiki.libsdl.org/SDL2/SDL_MouseMotionEvent

void CMyApp::MouseMove(const SDL_MouseMotionEvent& mouse)
{
	m_cameraManipulator.MouseMove(mouse);
}

// https://wiki.libsdl.org/SDL2/SDL_MouseButtonEvent

void CMyApp::MouseDown(const SDL_MouseButtonEvent& mouse)
{
	if (m_IsCtrlDown)
	{
		m_IsPicking = true;
	}
	m_PickedPixel = { mouse.x, mouse.y };
}

void CMyApp::MouseUp(const SDL_MouseButtonEvent& mouse)
{
}

// https://wiki.libsdl.org/SDL2/SDL_MouseWheelEvent

void CMyApp::MouseWheel(const SDL_MouseWheelEvent& wheel)
{
	m_cameraManipulator.MouseWheel(wheel);
}

// a két paraméterben az új ablakméret szélessége (_w) és magassága (_h) található
void CMyApp::Resize(int _w, int _h)
{
	glViewport(0, 0, _w, _h);
	m_windowSize = glm::uvec2(_w, _h);
	m_camera.SetAspect(static_cast<float>(_w) / _h);
}

// Le nem kezelt, egzotikus esemény kezelése
// https://wiki.libsdl.org/SDL2/SDL_Event

void CMyApp::OtherEvent(const SDL_Event& ev)
{

}
