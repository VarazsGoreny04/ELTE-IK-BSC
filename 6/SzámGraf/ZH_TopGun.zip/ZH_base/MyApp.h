#pragma once

// GLM
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/transform.hpp>

// GLEW
#include <GL/glew.h>

// SDL
#include <SDL2/SDL.h>
#include <SDL2/SDL_opengl.h>

// Utils
#include "Camera.h"
#include "CameraManipulator.h"
#include "GLUtils.hpp"

struct SUpdateInfo
{
	float ElapsedTimeInSec = 0.0f; // Program indulása óta eltelt idő 
	float DeltaTimeInSec = 0.0f;   // Előző Update óta eltelt idő 
};

struct Ray
{
	glm::vec3 origin;
	glm::vec3 direction;
};

struct Intersection
{
	glm::vec2 uv;
	float t;
};

struct Plane
{
	float startTime = 0;
	float duration = 0;

	glm::vec3 rotation = glm::vec3(0, 0, 0);
	glm::vec3 position = glm::vec3(0, 0, 0);
	float rFlap = 0;
	float lFlap = 0;
	float rTail = 0;
	float lTail = 0;
};

class CMyApp
{
public:
	CMyApp();
	~CMyApp();

	bool Init();
	void Clean();

	void Update(const SUpdateInfo&);
	void Render();
	void RenderGUI();

	void KeyboardDown(const SDL_KeyboardEvent&);
	void KeyboardUp(const SDL_KeyboardEvent&);
	void MouseMove(const SDL_MouseMotionEvent&);
	void MouseDown(const SDL_MouseButtonEvent&);
	void MouseUp(const SDL_MouseButtonEvent&);
	void MouseWheel(const SDL_MouseWheelEvent&);
	void Resize(int, int);

	void OtherEvent(const SDL_Event&);

protected:
	void SetupDebugCallback();

	// Enyém

	void DrawObject(OGLObject& obj, const glm::mat4& world);
	void RenderEarth();
	void RenderPlane();

	int formationSelected = 0;

	std::vector<std::vector<glm::vec3>> formations =
	{
		{glm::vec3(0.0f, 0.0f, 0.0f)},
		{
			glm::vec3(0.0f, 0.0f, 0.0f),
			glm::vec3(9,0,9),
			glm::vec3(-9,0,9),
			glm::vec3(9,0,-9),
			glm::vec3(-9,0,-9)
		},
		{
			glm::vec3(0.0f, 0.0f, 0.0f),
			glm::vec3(9,0,-9),
			glm::vec3(-9,0,-9),
			glm::vec3(-18,0,-18),
			glm::vec3(18,0,-18),
			glm::vec3(0,0,-18)
		},
		{}
	};

	Plane barrelRoll;

	float rFlap = 0;
	float lFlap = 0;
	float rTail = 0;
	float lTail = 0;

	bool doAFlip = false;

	float time = 1;

	// Adat változók

	float m_ElapsedTimeInSec = 0.0f;
	float m_LastElapsedTimeInSec = 0.0f;
	float m_GameElapsedTimeInSec = 0.0f;

	glm::mat4 m_objectWorldTransform;

	// Object params

	static constexpr glm::vec3 OBJECT_POS = glm::vec3( 0.0f, 0.0f, 0.0f );

	// Picking

	glm::ivec2 m_PickedPixel = glm::ivec2( 0, 0 );
	bool m_IsPicking = false;
	bool m_IsCtrlDown = false;

	glm::uvec2 m_windowSize = glm::uvec2(0, 0);

	Ray CalculatePixelRay(glm::vec2 pickerPos) const;


	// Kamera

	Camera m_camera;
	CameraManipulator m_cameraManipulator;

	// OpenGL-es dolgok

	// Shaderekhez szükséges változók 
	GLuint m_programID = 0; // shaderek programja 

	// Shaderek inicializálása, és törlése
	void InitShaders();
	void CleanShaders();

	// Geometriával kapcsolatos változók

	void SetCommonUniforms();

	OGLObject m_rectangleGPU = {};
	OGLObject m_planeFullBodyGPU = {};
	OGLObject m_planeRWingFlapGPU = {};
	OGLObject m_planeLWingFlapGPU = {};
	OGLObject m_planeRTailFlapGPU = {};
	OGLObject m_planeLTailFlapGPU = {};

	// Geometria inicializálása, és törlése
	void InitGeometry();
	void CleanGeometry();

	// Textúrázás, és változói
	GLuint m_SamplerID = 0;
	GLuint m_RepeatSamplerID = 0;

	GLuint m_cubeTextureID = 0;
	GLuint m_planeTextureID = 0;
	GLuint m_skyTextureID = 0;
	GLuint m_groundTextureID = 0;
	GLuint m_skyMapTextureID = 0;

	void InitTextures();
	void CleanTextures();
};
